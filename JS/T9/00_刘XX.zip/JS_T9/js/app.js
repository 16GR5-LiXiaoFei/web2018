/**
 * 0，获取所有图片盒子的对象
 * 1，获取每个图片的宽度
 * 2，计算当前窗口能放下多少个图片(需要获取每个图片的宽度)
 * 3，获取当前行高度的数组
 * 4，计算最小的高度
 * 5，下一个图片应该放在最小高度正下面（循环）
 * 
 * 6，添加窗口滚动事件
 * 7，判断自动加载的条件（最后一个图片盒子的高度<=窗口高度+滚动的距离）
 * 8，请求数据，动态的添加新增元素
 * */

window.onload = function(){
	//整体容器的对象
	var container = document.getElementById("container");
	
	imgload();
	
	var imgData = {"data":[{"src":"img/17.png"},{"src":"img/18.png"},{"src":"img/19.png"},{"src":"img/20.png"},{"src":"img/21.png"}]};
	//添加滚动事件
	window.onscroll = function(){
		if(isLoadMore()){
			//TODO
			for (var i = 0; i < imgData.data.length; i++) {
				//imgData.data[i].src;
				//创建box div元素
				var divBox = document.createElement("div");
				divBox.className = "box";
				//创建box_img div元素
				var divBoxImg = document.createElement("div");
				divBoxImg.className = "box_img";
				//创建img元素
				var img = document.createElement("img");
				//设置图片的路径
				img.src = imgData.data[i].src;
				
				//把图片添加到divBoxImg中
				divBoxImg.appendChild(img);
				//把divBoxImg添加到divBox中
				divBox.appendChild(divBoxImg);
				//把整个图片盒子添加容器中
				container.appendChild(divBox);
			}
			imgload();
		}
	};
};

function imgload(){
	//所有图片盒子的对象
	var content = document.getElementsByClassName("box");
	//所有图片盒子的宽度
	var imgWidth = content[0].offsetWidth;
	//console.log("盒子宽度:"+imgWidth);
	//当前窗口的宽度
	var winWidth = document.documentElement.clientWidth || document.body.clientWidth;
	//向下取整获取每行最终能放下图片盒子的数量（列数）
	var cols = Math.floor(winWidth/imgWidth);
	//console.log("列数:"+cols);
	//设置容器的宽度，并居中
	container.style.width = imgWidth*cols+"px";
	//console.log("container宽度:"+imgWidth*cols);
	container.style.margin = "0px auto";
//	container.style.cssText = "width:"+(imgWidth*cols)+"px;margin:0 auto";
	//获取当前行高度的数组
	var heigthArr = [];
	//console.log("最小高度："+minHeight);
	
	for (var i = 0; i < content.length; i++) {
		if(i<cols){
			heigthArr[i] = content[i].offsetHeight;
		}else{
			//计算最小的高度
			var minHeight = Math.min.apply(null,heigthArr);
			//console.log("最小高度:"+minHeight);
			//获取最小高度的索引
			var minHeightIndex = getMinHeightIndex(heigthArr,minHeight);
			//console.log("最小高度的索引:"+minHeightIndex);
			//设置当前盒子为绝对定位
			content[i].style.position = "absolute";
			content[i].style.top = minHeight+"px";
			content[i].style.left = content[minHeightIndex].offsetLeft+"px";
			//更新原最低高度的数据
			heigthArr[minHeightIndex] = minHeight+content[i].offsetHeight;
		}
	}
}

//判断自动加载的条件（最后一个图片盒子的高度<=窗口高度+滚动的距离）
function isLoadMore(){
	//所有的盒子数组
	var contents = document.getElementsByClassName("box");
	//最后一个图片盒子的高度
	var lastHeight = contents[contents.length-1].offsetTop + contents[contents.length-1].offsetHeight;
	console.log("最后图片的高度:"+lastHeight);
	//窗口高度
	var winHeight = document.documentElement.clientHeight || document.body.clientHeight;
	console.log("窗口的高度:"+winHeight);
	//滚动的距离
	var scollY = window.scrollY;
	console.log("垂直方向滚动的距离:"+scollY);
	if(lastHeight <= (winHeight+scollY)){
		return true;
	}
}

function getMinHeightIndex(heigthArr,minHeight){
	for(var i=0;i<heigthArr.length;i++){
		if(heigthArr[i] == minHeight){
			return i;
		}
	}
}
